<!DOCTYPE html>
<html>

<body>
	<form method="post" action="{{ url('admin/mapel/store') }}">@csrf
<table>
			<tr>
				<td>Nama Mapel</td>
				<td><input type="text" name="nama_mapel" required></td>
			</tr>
			<tr>
				<td>Kategori</td>
				<td><select name="kategori" required>
						<option value="Produktif">produktif</option>
						<option value="Adaptif">Adaptif</option>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>