<!DOCTYPE html>
<html>

<body>
	<form method="post" action="{{ url('admin/kelas/store') }}">@csrf
<table>
			<tr>
				<td>Nama Kelas</td>
				<td><input type="text" name="nama_kelas" required></td>
			</tr>
			<tr>
				<td>Jurusan</td>
				<td><input type="text" name="jurusan" required></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>