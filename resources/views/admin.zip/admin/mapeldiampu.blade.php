@extends('admin.Layout.AdminNavbar')
<h1>Halaman Data Mapel Diampu admin</h1>
<a href="{{url('admin/tambahmapeldiampu')}}">Tambah Mapel Diampu</a>{{ csrf_field() }}
<p>Cari Data Mapel :</p>
<form action="{{url('admin/mapeldiampu/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari mapeldiampu.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<a href="{{ route('mapeldiampu.export.pdf') }}" target="_blank">
    Export PDF
</a>
<x-alert />
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
    <tr>
        <th>No</th>
        <th>ID Ampu</th>
        <th>ID Guru</th>
        <th>ID Mapel</th>
        <th>ID Kelas</th>
        <th>Aksi</th>
    </tr>
    @foreach ($arraymapeldiampu as $key => $mapeldiampu)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $mapeldiampu->id_ampu }}</td>
        <td>{{ $mapeldiampu->id_guru }}</td>
        <td>{{ $mapeldiampu->id_mapel }}</td>
        <td>{{ $mapeldiampu->id_kelas }}</td>
        <td>
            <a href="{{url('admin/editmapeldiampu/'.$mapeldiampu->id_ampu)}}">Edit</a>
            |
            <a href="{{url('admin/hapusmapeldiampu/'.$mapeldiampu->id_ampu)}}" class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>