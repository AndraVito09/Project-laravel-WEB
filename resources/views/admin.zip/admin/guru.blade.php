@extends('admin.Layout.AdminNavbar')
<h1>Halaman Data Guru admin</h1>
<a href="{{url('admin/tambahguru')}}">Tambah Guru</a>{{ csrf_field() }}
<p>Cari Data Guru :</p>
<form action="{{url('admin/guru/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari guru.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<a href="{{ route('guru.export.pdf') }}" target="_blank">
    Export PDF
</a>
<x-alert />
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
    <tr>
        <th>No</th>
        <th>ID_guru</th>
        <th>NIP</th>
        <th>Nama</th>
        <th>Jenis Kelamin</th>
        <th>Email</th>
        <th>NO HP</th>
        <th>Aksi</th>
    </tr>
    @foreach ($arrayguru as $key => $guru)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $guru->id_guru }}</td>
        <td>{{ $guru->nip }}</td>
        <td>{{ $guru->nama }}</td>
        <td>{{ $guru->jenis_kelamin }}</td>
        <td>{{ $guru->email }}</td>
        <td>{{ $guru->no_hp }}</td>
        <td>
            <a href="{{url('admin/editguru/'.$guru->id_guru)}}">Edit</a>
            |
            <a href="{{url('admin/hapusguru/'.$guru->id_guru)}}" class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>