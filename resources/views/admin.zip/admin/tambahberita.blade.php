<!DOCTYPE html>
<html>

<body>
	<form method="post" action="{{ url('admin/berita/store') }}">@csrf
<table>
			<tr>
				<td>Judul</td>
				<td><input type="text" name="judul" required></td>
			</tr>
			<tr>
				<td>Isi</td>
				<td><input type="text" name="isi" required></td>
			</tr>
      <tr>
				<td>Tanggal Post</td>
				<td><input type="date" name="tanggal_post" required></td>
			</tr>
      <tr>
				<td>ID_Guru</td>
				<td><select name="id_guru" required>
    ‎           <option value="">----</option>
                @foreach($guru as $g)
                <option value="{{$g->id_guru}}">{{ $g->id_guru}} - {{$g->nama}}</option>
                @endforeach
            </select></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>