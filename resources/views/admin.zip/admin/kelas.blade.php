@extends('admin.Layout.AdminNavbar')
<h1>Halaman Data Kelas admin</h1>
<a href="{{url('admin/tambahkelas')}}">Tambah Kelas</a>{{ csrf_field() }}
<p>Cari Data Kelas :</p>
<form action="{{url('admin/kelas/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari kelas.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<a href="{{ route('kelas.export.pdf') }}" target="_blank">
    Export PDF
</a>
<x-alert />
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
    <tr>
        <th>No</th>
        <th>ID Kelas</th>
        <th>Nama Kelas</th>
        <th>Jurusan</th>
    </tr>
    @foreach ($arraykelas as $key => $kelas)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $kelas->id_kelas }}</td>
        <td>{{ $kelas->nama_kelas }}</td>
        <td>{{ $kelas->jurusan }}</td>
        <td>
            <a href="{{url('/admin/editkelas/'.$kelas->id_kelas)}}">Edit</a>
            |
            <a href="{{url('admin/hapuskelas/'.$kelas->id_kelas)}}" class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>