<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Admin Panel')</title>
    <link rel="stylesheet" href="{{ asset('style.css') }}">
</head>

<body>

@include('admin.Layout.Navbar')

<div class="admin-layout">
    @yield('content')
</div>
<script src="{{ asset('js/alert.js') }}"></script>
</body>
</html>