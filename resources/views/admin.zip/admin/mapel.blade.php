@extends('admin.Layout.AdminNavbar')
<h1>Halaman Data Mapel admin</h1>
<a href="{{url('admin/tambahmapel')}}">Tambah Mapel</a>{{ csrf_field() }}
<p>Cari Data Mapel :</p>
<form action="{{url('admin/mapel/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari mapel.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<a href="{{ route('mapel.export.pdf') }}" target="_blank">
    Export PDF
</a>
<x-alert />
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
    <tr>
        <th>No</th>
        <th>ID Mapel</th>
        <th>Nama Mapel</th>
        <th>Kategori</th>
        <th>Aksi</th>
    </tr>
    @foreach ($arraymapel as $key => $mapel)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $mapel->id_mapel }}</td>
        <td>{{ $mapel->nama_mapel }}</td>
        <td>{{ $mapel->kategori }}</td>
        <td>
            <a href="{{url('admin/editmapel/'.$mapel->id_mapel)}}">Edit</a>
            |
            <a href="{{url('admin/hapusmapel/'.$mapel->id_mapel)}}" class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>