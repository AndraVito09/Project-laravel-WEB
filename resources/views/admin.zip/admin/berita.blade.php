@extends('admin.Layout.AdminNavbar')
<h1>Halaman Data Berita </h1>
<a href="{{ url('admin/tambahberita') }}" class="btn btn-primary">+ Tambah Berita</a>{{ csrf_field() }}
<p>Cari Data Guru :</p>
<form action="{{url('admin/berita/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari berita.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<a href="{{ route('berita.export.pdf') }}" target="_blank">
    Export PDF
</a>
<x-alert />
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
    <tr>
        <th>No</th>
        <th>ID Berita</th>
        <th>Judul</th>
        <th>Isi</th>
        <th>Tanggal Post</th>
        <th>Id guru</th>
    </tr>
    @foreach ($arrayberita as $key => $berita)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $berita->id_berita }}</td>
        <td>{{ $berita->judul }}</td>
        <td>{{ $berita->isi }}</td>
        <td>{{ $berita->tanggal_post }}</td>
        <td>{{ $berita->id_guru }}</td>
        <td>
            <a href="{{url('admin/editberita/'.$berita->id_berita)}}">Edit</a>
            |
            <a href="{{url('admin/hapusberita/'.$berita->id_berita)}} " class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>