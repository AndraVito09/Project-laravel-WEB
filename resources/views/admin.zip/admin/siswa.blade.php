<html>
<head></head>
<body>
@extends('admin.Layout.AdminNavbar')
@section('content')
<h1>Halaman Data Siswa admin</h1>
<a href="{{ url('admin/tambahsiswa') }}" class="btn btn-primary">+ Tambah Siswa</a>{{ csrf_field() }}
<p>Cari Data siswa :</p>
<form action="{{url('admin/siswa/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari siswa.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<x-alert />
<a href="{{ route('siswa.export.pdf') }}" target="_blank">
    Export PDF
</a>
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
        <tr>
            <th>No</th>
            <th>NISN</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Tanggal Lahir</th>
            <th>Foto</th>
            <th>Id Siswa</th>
            <th>Id Kelas</th>
            <th>Alamat</th>
            <th>NO HP</th>
            <th>Aksi</th>
        </tr>
    @foreach ($arraysiswa as $key => $siswa)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $siswa->nisn }}</td>
        <td>{{ $siswa->nama }}</td>
        <td>{{ $siswa->jk }}</td>
        <td>{{ $siswa->tanggal_lahir }}</td>
        <td><img src = "{{ $siswa->foto }}" width='100'></td>
        <td>{{ $siswa->id_siswa }}</td>
        <td>{{ $siswa->id_kelas }}</td>
        <td>{{ $siswa->alamat }}</td>
        <td>{{ $siswa->no_hp }}</td>
        <td>
            <a href="{{url('admin/editsiswa/'.$siswa->id_siswa)}}">Edit</a>
            |
            <a href="{{url('admin/hapussiswa/'.$siswa->id_siswa)}}" class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </body>
</html>