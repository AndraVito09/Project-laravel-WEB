@extends('admin.Layout.AdminNavbar')
<h1>Halaman Data Nilai admin</h1>
<a href="{{ url('admin/tambahnilai') }}" class="btn btn-primary">+ Tambah Nilai</a>{{ csrf_field() }}
<p>Cari Data Mapel :</p>
<form action="{{url('admin/nilai/cari')}}" method="GET">
    <input type="text" name="cari" placeholder="Cari nilai.." value="{{ old('cari') }}">
    <input type="submit" value="CARI">
</form>
<a href="{{ route('nilai.export.pdf') }}" target="_blank">
    Export PDF
</a>
<x-alert />
@if(session('success'))
<script>
    alert("{{ session('success') }}");
</script>
@endif
<table border="1">
    <tr>
        <th>No</th>
        <th>ID Nilai</th>
        <th>ID Siswa</th>
        <th>ID Ampu</th>
        <th>Semester</th>
        <th>Nilai Tugas</th>
        <th>NIlai UTS</th>
        <th>Nilai Akhir</th>
        <th>Aksi</th>
    </tr>
    @foreach ($arraynilai as $key => $nilai)
    <tr>
        <td>{{ $key + 1 }}</td>
        <td>{{ $nilai->id_nilai }}</td>
        <td>{{ $nilai->id_siswa }}</td>
        <td>{{ $nilai->id_ampu }}</td>
        <td>{{ $nilai->semester }}</td>
        <td>{{ $nilai->nilai_tugas }}</td>
        <td>{{ $nilai->nilai_uts }}</td>
        <td>{{ $nilai->nilai_akhir }}</td>
        <td>
            <a href="{{url('admin/editnilai/'.$nilai->id_nilai)}}">Edit</a>
            |
            <a href="{{url('admin/hapusnilai/'.$nilai->id_nilai)}}" class="btn-delete">Hapus</a>
        </td>
    </tr>
    @endforeach
    </table>