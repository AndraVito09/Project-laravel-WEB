<!DOCTYPE html>
<html>

<body>
	<form method="post" action="{{ url('admin/berita/update') }}"> {{ csrf_field() }}
<table>
			<tr>			
				<td></td>
				<td><input type="hidden" name="id_berita" value="{{$berita->id_berita}}"></td>
			</tr>
			<tr>
				<td>Judul</td>
				<td><input type="text" name="judul" value="{{$berita->judul}}" required></td>
			</tr>
			<tr>
				<td>Isi</td>
				<td><input type="text" name="isi" value="{{$berita->isi}}" required></td>
			</tr>
      <tr>
				<td>Tanggal Post</td>
				<td><input type="date" name="tanggal_post" value="{{$berita->tanggal_post}}" required></td>
			</tr>
      <tr>
				<td>ID_Guru</td>
				<td><select name="id_guru" required>
    ‎           <option value="">----</option>
                @foreach($guru as $g)
                @php $selected = ($g->id_guru == $berita->id_guru) ? 'selected' : ''; @endphp
                <option value="{{$g->id_guru}}" {{$selected}}>{{ $g->id_guru}} - {{$g->nama}}</option>
                @endforeach
            </select></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Update"></td>
			</tr>		
		</table>
	</form>
</body>
</html>