@extends('admin.Layout.AdminNavbar')
@section('content')
<div class="container">
    <h1>Data Mata Pelajaran</h1>
    
    <div class="header-actions">
        <a href="{{ url('admin/tambahmapel') }}" class="btn-primary">+ Tambah Mapel</a>{{ csrf_field() }}
        <a href="{{ route('mapel.export.pdf') }}" target="_blank">Export PDF</a>
    </div>
    
    <div class="search-section">
        <p>Cari Data Mapel :</p>
        <form action="{{url('admin/mapel/cari')}}" method="GET">
            <input type="text" name="cari" placeholder="Cari mapel.." value="{{ old('cari') }}">
            <input type="submit" value="CARI">
        </form>
    </div>
    
    <x-alert />
    
    @if(session('success'))
    <script>
        alert("{{ session('success') }}");
    </script>
    @endif
    
    <div class="cards-grid">
        @forelse ($arraymapel as $key => $mapel)
        <div class="data-card">
            <div class="card-number">{{ $key + 1 }}</div>
            
            <div class="card-content">

                <div class="card-field">
                    <span class="field-label">ID Mapel</span>
                    <span class="field-value">{{ $mapel->id_mapel }}</span>
                </div>

                <div class="card-field">
                    <span class="field-label">Nama Mapel</span>
                    <span class="field-value">{{ $mapel->nama_mapel }}</span>
                </div>

                <div class="card-field">
                    <span class="field-label">kategori</span>
                    <span class="field-value">{{ $mapel->kategori }}</span>
                </div>

            </div>
            
            <div class="card-actions">
                <a href="{{url('admin/editmapel/'.$mapel->id_mapel)}}" class="btn-edit">Edit</a>
                <a href="{{url('admin/hapusmapel/'.$mapel->id_mapel)}}" class="btn-delete">Hapus</a>
            </div>
        </div>
        @empty
        <div class="not-found">
            Data Tidak Ditemukan
        </div>
        @endforelse
    </div>
</div>
@endsection